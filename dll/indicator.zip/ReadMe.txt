After downloading Download.zip from the server, do the following

1. Unzip Download.zip
2. Cut and paste Technests on to your C:\ Drive
3. Login to Ninjatrader 
4. Add TradeRx.zip - Tools -> Import -> NinjaScript Add-on -> TradeRx.zip
5. Wait for success message
5. Restart Ninjatrader

First time setting up TradeRx

1. Login to Ninjatrader
2. Open Chart [New->Chart] and load a US Futures Instrument (For example-ES)
3. Setup as per your strategy
4. Input your subscription email ID
5. Enter your prop account and firm rules
6. Click Apply

Daily Routine

1. Login to Ninjatrader 
2. Open a Chart and Load your Instrument
3. Open NinjaScript Output [New->NinjaScript Output]
3. Load TradeRx Indicator
4. Review and set your strategy as required
5. Click Apply
4. Monitor Chart and NinjaScript Output window for latest updates




