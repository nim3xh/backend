PropTraderPro — EMA20TCrossover
By Technests

1. Download & Install
When you download the ZIP file, extract all contents to your computer.
Inside the ZIP, you will find:
EMA20TCrossover.dll
Config.dll
readme.txt

A. Install the Indicator
1. Open NinjaTrader.
2. Go to Control Center → Tools → Import → NinjaScript Add-On.
3. Select the ZIP file (PropTraderProV1.0.zip).
4. Restart NinjaTrader after import.

B. Install Config.dll
Copy this file into:
C:\Technests\Config\

2. Required Folder Structure
C:\Temp\
C:\Technests\
C:\Technests\Results\
C:\Technests\Accounts\
C:\Technests\Config\

3. Subscription File
C:\Technests\Subscription.lic
Save your subscription email ID inside this file. It is checked daily.

4. Trader’s Dashboard (Rithmic)
Download from R|Trader Pro → Trader Dashboard.
Save to:
C:\Temp\
Rename to:
Traders-Dashboard-Apex.csv

5. Daily Routine
A. Preparation
Restart computer.
Download dashboard → save as:
C:\Temp\Traders-Dashboard-Apex.csv
Verify subscription email in:
C:\Technests\Subscription.lic

B. Start NinjaTrader
Load US Futures contract (MES recommended).
Add indicator: Right-click chart → Indicators → PropTraderPro → Add.

C. During Trading Hours
Keep indicator active.
Monitor trades.

D. One Hour Before Market Close
Flatten all trades.
Check for stray orders.

E. End Of Day
Close NinjaTrader.
Restart computer.

6. Support
Contact Technests Support for assistance.
